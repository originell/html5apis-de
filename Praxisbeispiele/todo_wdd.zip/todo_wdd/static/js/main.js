!function() {
    var todo = document.forms.todoForm.todo,
        form = document.forms.todoForm,
        todoList = document.querySelector('#todo_list'),
        count = 0;

    var existing_count = localStorage.getItem('todo:count');
    if (existing_count) {
        count = existing_count;
        for (var i = 0; i < existing_count; i++) {
            // Basteln wir uns den Schlüssel unter dem das Todo gespeicher ist
            var key = 'todo:' + i;
            // Da holen wir uns beispielsweise todo:1 aus dem localStorage
            var stored_todo = localStorage.getItem(key);
            // und bauen uns wieder ein listen element
            var new_li = document.createElement('li');
            // welches den gespeicherten wert bekommt
            new_li.innerText = stored_todo;
            // uuuund fügen wir das ganze zu unserer existierenden todo liste hinzu.
            todoList.appendChild(new_li);
        }
    }

    form.addEventListener('submit', function(event) {
        // Normal übliche Browseraktion verhindern (seite neuladen, formular abschicken...)
        event.preventDefault();

        var li = document.createElement('li');
        li.innerText = todo.value;
        todoList.appendChild(li);
        localStorage.setItem('todo:'+count, todo.value);
        console.log('SET', 'todo:'+count, 'to', todo.value);
        count++;
        localStorage.setItem('todo:count', count);

        todo.value = '';
    });
}();
