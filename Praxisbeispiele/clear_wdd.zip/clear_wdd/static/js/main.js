!function() {
    var app = ToDo.init();

}();
