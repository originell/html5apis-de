Standalone Version der Presentation ohne die Demo-Modus Skripte.

Der Inhalt dieses Ordners liegt ebenfalls in der `standalone.zip` im
Quellverzeichnis, fertig für den Download.
